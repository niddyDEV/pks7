# pks_7

Товмасян Григорий ЭФБО-04-22


https://github.com/user-attachments/assets/ca0e6934-f58b-4f8b-b44d-e5009e039188

